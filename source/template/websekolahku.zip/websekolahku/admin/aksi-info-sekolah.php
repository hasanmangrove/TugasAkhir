<?php
include ('koneksi/koneksi.php');
$id_info_sekolah=$_POST['id_info_sekolah'];
$judul_info_sekolah=$_POST['judul_info_sekolah'];
$isi_info_sekolah=($_POST['isi_info_sekolah']);
$pengirim=($_POST['pengirim']);
$jam_posting=($_POST['jam_posting']);
$tanggal_posting=($_POST['tanggal_posting']);
if (isset($_POST['tambah'])){
$query="INSERT INTO tb_info_sekolah (id_info_sekolah,judul_info_sekolah,isi_info_sekolah,pengirim,posttime,postdate) 
values('','$judul_info_sekolah','$isi_info_sekolah','$pengirim','$jam_posting','$tanggal_posting')"or die(mysql_error());
$tambah=mysql_query($query);			
	if($query){
			?><script language="JavaScript">
			alert('Info sekolah berhasil di tambahkan !');
			document.location='page.php?pg=info-sekolah';
		</script><?php
		}	
}
else if ($_POST['update']){
$ubah = mysql_query("UPDATE tb_info_sekolah SET  id_info_sekolah='$id_info_sekolah',judul_info_sekolah='$judul_info_sekolah',
isi_info_sekolah='$isi_info_sekolah',
pengirim='$pengirim',
posttime='$jam_posting',
postdate='$tanggal_posting'
 where id_info_sekolah='$id_info_sekolah'")or die(mysql_error());
if($ubah){		
?>
			<script language="JavaScript">
			alert('Info sekolah berhasil di ubah !');
			document.location='page.php?pg=info-sekolah';
		</script>
<?php
		}
}
else if ($_GET['hapus']){
$id_info_sekolah = $_GET['hapus'];
$del="DELETE FROM tb_info_sekolah where id_info_sekolah='$id_info_sekolah'";
  $del= mysql_query($del);
if($del){
			?><script language="JavaScript">
			alert('Info sekolah berhasil di hapus !');
			document.location='page.php?pg=info-sekolah';
		</script><?php
		}
}
header("location:page.php?pg=info-sekolah");
?>