<?php
include ('koneksi/koneksi.php');
$id=$_POST['id'];
$kode_jurusan=$_POST['kode_jurusan'];
$nama_jurusan=($_POST['nama_jurusan']);
$nama_sekolah=($_POST['nama_sekolah']);
if (isset($_POST['tambah'])){
$query="INSERT INTO tb_jurusan (id_jurusan,kode_jurusan,nama_jurusan,nama_sekolah) values('','$kode_jurusan','$nama_jurusan','$nama_sekolah')"or die(mysql_error());
$tambah=mysql_query($query);			
	if($query){
			?><script language="JavaScript">
			alert('Data jurusan berhasil di tambahkan !');
			document.location='page.php?pg=jurusan';
		</script><?php
		}	
}
else if ($_POST['update']){
$ubah = mysql_query("UPDATE tb_jurusan SET kode_jurusan='$kode_jurusan',nama_jurusan='$nama_jurusan',nama_sekolah='$nama_sekolah' where id_jurusan='$id'")or die(mysql_error());
if($ubah){		
?>
			<script language="JavaScript">
			alert('Data jurusan berhasil di ubah !');
			document.location='page.php?pg=jurusan';
		</script>
<?php
		}
}
else if ($_GET['hapus']){
$id_jurusan = $_GET['hapus'];
$del="DELETE FROM tb_jurusan where id_jurusan='$id_jurusan'";
  $del= mysql_query($del);
if($del){
			?><script language="JavaScript">
			alert('Data jurusan berhasil di hapus !');
			document.location='page.php?pg=jurusan';
		</script><?php
		}
}
header("location:page.php?pg=jurusan");
?>