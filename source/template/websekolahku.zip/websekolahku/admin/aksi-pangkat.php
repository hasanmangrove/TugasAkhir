<?php
include ('koneksi/koneksi.php');
$id_pangkat=$_POST['id_pangkat'];
$nama_pangkat=$_POST['nama_pangkat'];
if (isset($_POST['tambah'])){
$query="INSERT INTO tb_pangkat (id_pangkat,nama_pangkat) values('','$nama_pangkat')"or die(mysql_error());
$tambah=mysql_query($query);			
	if($query){
			?><script language="JavaScript">
			alert('Nama pangkat berhasil di tambahkan !');
			document.location='page.php?pg=pangkat';
		</script><?php
		}	
}
else if ($_POST['update']){
$ubah = mysql_query("UPDATE tb_pangkat SET nama_pangkat='$nama_pangkat' where id_pangkat='$id_pangkat'")or die(mysql_error());
if($ubah){		
?>
			<script language="JavaScript">
			alert('Nama pangkat berhasil di ubah !');
			document.location='page.php?pg=pangkat';
		</script>
<?php
		}
}
else if ($_GET['hapus']){
$id_pangkat = $_GET['hapus'];
$del="DELETE FROM tb_pangkat where id_pangkat='$id_pangkat'";
  $del= mysql_query($del);
if($del){
			?><script language="JavaScript">
			alert('Nama pangkat berhasil di hapus !');
			document.location='page.php?pg=pangkat';
		</script><?php
		}
}
header("location:page.php?pg=pangkat");
?>