<?php
include "excel_reader2.php";
$username = "root";
$password = "";
$database = "simpenan";
 
mysql_connect("localhost", $username, $password);
mysql_select_db($database);
 
// file yang tadinya di upload, di simpan di temporary file PHP, file tersebut yang kita ambil
// dan baca dengan PHP Excel Class
$data = new Spreadsheet_Excel_Reader($_FILES['fileexcelsiswa']['tmp_name']);
$hasildata = $data->rowcount($sheet_index=0);
 
 
 
for ($i=2; $i<=$hasildata; $i++)
{
  
  $id_siswa = $data->val($i,1); 
  $nis= $data->val($i,2); 
  $nama_siswa = $data->val($i,3);
  $tempat_lahir = $data->val($i,4);
  $tanggal_lahir= $data->val($i,5);
  $jenis_kelamin = $data->val($i,6);
  $agama= $data->val($i,7);
  $alamat= $data->val($i,8);
  $nomor_hp= $data->val($i,9);
  $email= $data->val($i,10);
  $jurusan= $data->val($i,11);
  $nilai= $data->val($i,12);
  $keterangan= $data->val($i,13);
  $nama_ayah= $data->val($i,14);
  $nama_ibu= $data->val($i,15);
  $photo= $data->val($i,16);
  $status= $data->val($i,17);
  
 
$query = "INSERT INTO tb_siswa (id_siswa,nis,nama_siswa,tempat_lahir,tanggal_lahir,jenis_kelamin,agama,alamat,nomor_hp,email,jurusan,nilai,keterangan,nama_ayah,nama_ibu,photo,status) 
VALUES ('$id_siswa','$nis','$nama_siswa','$tempat_lahir','$tanggal_lahir','$jenis_kelamin','$agama','$alamat','$nomor_hp','$email','$jurusan','$nilai','$keterangan','$nama_ayah','$nama_ibu','$photo','$status')";
$hasil = mysql_query($query);
 
}
 
 
if ($hasil) 
{?>
<script language="JavaScript">
			alert('Data siswa berhasil di import !');
			document.location='page.php?pg=siswa';
		</script>
<?php }
else
{?>
<script language="JavaScript">
			alert('Data siswa gagal di import !');
			document.location='page.php?pg=import_siswa';
		</script>
<?php }
?>