<?php
include ('koneksi/koneksi.php');
$nomor_registrasi=$_POST['nomor_registrasi'];
$nama_mahasiswa=($_POST['nama_mahasiswa']);
$tempat_lahir=($_POST['tempat_lahir']);
$tanggal_lahir=($_POST['tanggal_lahir']);
$jenis_kelamin=($_POST['jenis_kelamin']);
$nama_agama=($_POST['nama_agama']);
$nama_suku=($_POST['nama_suku']);
$nama_kebangsaan=($_POST['nama_kebangsaan']);
$status_mahasiswa=($_POST['status_mahasiswa']);
$nomor_hp=($_POST['nomor_hp']);
$email=($_POST['email']);
$pilihan_jurusan=($_POST['pilihan_jurusan']);
$pilihan_kelas=($_POST['pilihan_kelas']);
$nama_pekerjaan=($_POST['nama_pekerjaan']);
$nama_instansi=($_POST['nama_instansi']);
$nama_pangkat=($_POST['nama_pangkat']);
$nama_jabatan=($_POST['nama_jabatan']);
$alamat_instansi=($_POST['alamat_instansi']);
$asal_sekolah=($_POST['asal_sekolah']);
$jurusan_sekolah=($_POST['jurusan_sekolah']);
$tahun_masuk=($_POST['tahun_masuk']);
$tahun_lulus=($_POST['tahun_lulus']);
$pengalaman_organisasi=($_POST['pengalaman_organisasi']);
$pengalaman_kursus=($_POST['pengalaman_kursus']);
$nama_keterampilan=($_POST['nama_keterampilan']);
$nama_ayah=($_POST['nama_ayah']);
$nama_ibu=($_POST['nama_ibu']);
$pekerjaan_ayah=($_POST['pekerjaan_ayah']);
$pekerjaan_ibu=($_POST['pekerjaan_ibu']);
$penghasilan_ayah=($_POST['penghasilan_ayah']);
$penghasilan_ibu=($_POST['penghasilan_ibu']);
$nama_wali=($_POST['nama_wali']);
$keterangan_wali=($_POST['keterangan_wali']);
$alamat_wali=($_POST['alamat_wali']);
$kontak_wali=($_POST['kontak_wali']);
$status_tinggal=($_POST['status_tinggal']);
$photo=($_POST['photo']);
$status=($_POST['status']);
$sumber_informasi=($_POST['sumber_informasi']);
if (isset($_POST['tambah'])){
if ($_FILES['photo']['size'] != 0){
$fileName= $_FILES['photo']['name'];
$movefile = move_uploaded_file($_FILES['photo']['tmp_name'], 'img/mahasiswa/'.$fileName); 
}
$query="INSERT INTO tb_mahasiswa (id_mahasiswa,nomor_registrasi,nama_mahasiswa,tempat_lahir,tanggal_lahir,jenis_kelamin,
agama,suku,kebangsaan,status_mahasiswa,nomor_hp,email,pilihan_jurusan1,pilihan_kelas,nama_pekerjaan,nama_instansi,nama_pangkat,nama_jabatan,alamat_instansi,asal_sekolah,jurusan_sekolah,tahun_masuk,tahun_lulus,
pengalaman_organisasi,pengalaman_kursus,nama_keterampilan,nama_ayah,nama_ibu,pekerjaan_ayah,pekerjaan_ibu,
penghasilan_ayah,penghasilan_ibu,nama_wali,keterangan_wali,alamat_wali,kontak_wali,status_tinggal,sumber_informasi,photo,status)
values('','$nomor_registrasi','$nama_mahasiswa','$tempat_lahir','$tanggal_lahir','$jenis_kelamin',
'$nama_agama','$nama_suku','$nama_kebangsaan','$status_mahasiswa','$nomor_hp','$email',
'$pilihan_jurusan','$pilihan_kelas','$nama_pekerjaan','$nama_instansi','$nama_pangkat','$nama_jabatan',
'$alamat_instansi','$asal_sekolah','$jurusan_sekolah','$tahun_masuk','$tahun_lulus','$pengalaman_organisasi',
'$pengalaman_kursus','$nama_keterampilan','$nama_ayah','$nama_ibu','$pekerjaan_ayah','$pekerjaan_ibu',
'$penghasilan_ayah','$penghasilan_ibu','$nama_wali','$keterangan_wali','$alamat_wali',
'$kontak_wali','$status_tinggal','$sumber_informasi','$fileName','$status')"or die(mysql_error());
$tambah=mysql_query($query);			
	if($query){
			?><script language="JavaScript">
			alert('Data mahasiswa berhasil di tambahkan !');
			document.location='page.php?pg=mahasiswa';
		</script><?php
		}	
}
else if ($_POST['update']){
$id=$_POST['id'];
$ednomor_registrasi=$_POST['ednomor_registrasi'];
$ednama_mahasiswa=($_POST['ednama_mahasiswa']);
$edtempat_lahir=($_POST['edtempat_lahir']);
$edtanggal_lahir=($_POST['edtanggal_lahir']);
$edjenis_kelamin=($_POST['edjenis_kelamin']);
$ednama_agama=($_POST['ednama_agama']);
$ednama_suku=($_POST['ednama_suku']);
$ednama_kebangsaan=($_POST['ednama_kebangsaan']);
$edstatus_mahasiswa=($_POST['edstatus_mahasiswa']);
$ednomor_hp=($_POST['ednomor_hp']);
$edemail=($_POST['edemail']);
$edpilihan_jurusan=($_POST['edpilihan_jurusan']);
$edpilihan_kelas=($_POST['edpilihan_kelas']);
$ednama_pekerjaan=($_POST['ednama_pekerjaan']);
$ednama_instansi=($_POST['ednama_instansi']);
$ednama_pangkat=($_POST['ednama_pangkat']);
$ednama_jabatan=($_POST['ednama_jabatan']);
$edalamat_instansi=($_POST['edalamat_instansi']);
$edasal_sekolah=($_POST['edasal_sekolah']);
$edjurusan_sekolah=($_POST['edjurusan_sekolah']);
$edtahun_masuk=($_POST['edtahun_masuk']);
$edtahun_lulus=($_POST['edtahun_lulus']);
$edpengalaman_organisasi=($_POST['edpengalaman_organisasi']);
$edpengalaman_kursus=($_POST['edpengalaman_kursus']);
$ednama_keterampilan=($_POST['ednama_keterampilan']);
$ednama_ayah=($_POST['ednama_ayah']);
$ednama_ibu=($_POST['ednama_ibu']);
$edpekerjaan_ayah=($_POST['edpekerjaan_ayah']);
$edpekerjaan_ibu=($_POST['edpekerjaan_ibu']);
$edpenghasilan_ayah=($_POST['edpenghasilan_ayah']);
$edpenghasilan_ibu=($_POST['edpenghasilan_ibu']);
$ednama_wali=($_POST['ednama_wali']);
$edketerangan_wali=($_POST['edketerangan_wali']);
$edalamat_wali=($_POST['edalamat_wali']);
$edkontak_wali=($_POST['edkontak_wali']);
$edstatus_tinggal=($_POST['edstatus_tinggal']);
$edphoto=($_POST['edphoto']);
$edstatus=($_POST['edstatus']);
$edsumber_informasi=($_POST['edsumber_informasi']);
if ($_FILES['edphoto']['size'] != 0){
$filephoto= $_FILES['edphoto']['name'];
$ubahfile = move_uploaded_file($_FILES['edphoto']['tmp_name'], 'img/mahasiswa/'.$filephoto); 
}
$ubah = mysql_query("UPDATE tb_mahasiswa SET nomor_registrasi='$ednomor_registrasi',
nama_mahasiswa='$ednama_mahasiswa',
tempat_lahir='$edtempat_lahir',
tanggal_lahir='$edtanggal_lahir',
jenis_kelamin='$edjenis_kelamin',
agama='$ednama_agama',
suku='$ednama_suku',
kebangsaan='$ednama_kebangsaan',
status_mahasiswa='$edstatus_mahasiswa',
nomor_hp='$ednomor_hp',
email='$edemail',
pilihan_jurusan1='$edpilihan_jurusan',
pilihan_kelas='$edpilihan_kelas',
nama_pekerjaan='$ednama_pekerjaan',
nama_instansi='$ednama_instansi',
nama_pangkat='$ednama_pangkat',
nama_jabatan='$ednama_jabatan',
alamat_instansi='$edalamat_instansi',
asal_sekolah='$edasal_sekolah',
jurusan_sekolah='$edjurusan_sekolah',
tahun_masuk='$edtahun_masuk',
tahun_lulus='$edtahun_lulus',
pengalaman_organisasi='$edpengalaman_organisasi',
pengalaman_kursus='$edpengalaman_kursus',
nama_keterampilan='$ednama_keterampilan',
nama_ayah='$ednama_ayah',
nama_ibu='$ednama_ibu',
pekerjaan_ayah='$edpekerjaan_ayah',
pekerjaan_ibu='$edpekerjaan_ibu',
penghasilan_ayah='$edpenghasilan_ayah',
penghasilan_ibu='$edpenghasilan_ibu',
nama_wali='$ednama_wali',
keterangan_wali='$edketerangan_wali',
alamat_wali='$edalamat_wali',
kontak_wali='$edkontak_wali',
status_tinggal='$edstatus_tinggal',
sumber_informasi='$edsumber_informasi',
photo='$filephoto',
status='$edstatus' where id_mahasiswa='$id'")or die(mysql_error());
if($ubah){		
?>
			<script language="JavaScript">
			alert('Data mahasiswa berhasil di ubah !');
			document.location='page.php?pg=mahasiswa';
		</script>
<?php
		}
}
else if ($_GET['hapus']){
$id_mahasiswa = $_GET['hapus'];
$del="DELETE FROM tb_mahasiswa where id_mahasiswa='$id_mahasiswa'";
  $del= mysql_query($del);
if($del){
			?><script language="JavaScript">
			alert('Data mahasiswa berhasil di hapus !');
			document.location='page.php?pg=mahasiswa';
		</script><?php
		}
}
header("location:page.php?pg=mahasiswa");
?>