<?php
include "koneksi/koneksi.php";
$username=$_POST['username'];
$password=md5($_POST['password']);
if (($_POST['username']=='') And ($_POST['password']=='')){
echo "<script language='JavaScript'>
			alert('Username dan Password tidak boleh kosong !');
			document.location='login';
		</script>";
}
if (($_POST['username']=='')){
echo "<script language='JavaScript'>
			alert('Username tidak boleh kosong !');
			document.location='login';
		</script>";
}
if (($_POST['password']=='')){
echo "<script language='JavaScript'>
			alert('Password tidak boleh kosong !');
			document.location='login';
		</script>";
}
if (($_POST['username']!='') And ($_POST['password']!='')){
$sql=mysql_query("SELECT * FROM user WHERE Username='$username' AND Password='$password'");
$level=mysql_num_rows($sql);
$register=mysql_fetch_array($sql);
if (($_POST['username']!=$register['Username']) And ($_POST['password']!=$register['Username']))echo "<script language='JavaScript'> alert('Username dan Password tidak benar !'); document.location='login'; </script>";
if ($level>=0){
 session_start();
 session_register("username");
 session_register("password");
 session_register("lvl");
 $_SESSION[username] = $register[Username];
 $_SESSION[password] = $register[Password];
 $_SESSION[lvl]= $register[Level];
 header('location:cek');
 }
 else{
 header('location:login');
 }
 }
?>