<?php
include ('koneksi/koneksi.php');
$id_kategori=$_POST['id_kategori'];
$kategori=$_POST['nama_kategori'];
$jenis=($_POST['jenis_kategori']);
if (isset($_POST['tambah'])){
$query="INSERT INTO tb_kategori (id_kategori,kategori,jenis) values('','$kategori','$jenis')"or die(mysql_error());
$tambah=mysql_query($query);			
	if($query){
			?><script language="JavaScript">
			alert('Data kategori berhasil di tambahkan !');
			document.location='page.php?pg=kategori';
		</script><?php
		}	
}
else if ($_POST['update']){
$ubah = mysql_query("UPDATE tb_kategori SET  id_kategori='$id_kategori',kategori='$kategori',jenis='$jenis' where id_kategori='$id_kategori'")or die(mysql_error());
if($ubah){		
?>
			<script language="JavaScript">
			alert('Data kategori berhasil di ubah !');
			document.location='page.php?pg=kategori';
		</script>
<?php
		}
}
else if ($_GET['hapus']){
$id_kategori = $_GET['hapus'];
$del="DELETE FROM tb_kategori where id_kategori='$id_kategori'";
  $del= mysql_query($del);
if($del){
			?><script language="JavaScript">
			alert('Data jurusan berhasil di hapus !');
			document.location='page.php?pg=kategori';
		</script><?php
		}
}
header("location:page.php?pg=jurusan");
?>