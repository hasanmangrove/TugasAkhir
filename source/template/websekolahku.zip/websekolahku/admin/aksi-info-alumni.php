<?php
include ('koneksi/koneksi.php');
$id_info_alumni=$_POST['id_info_alumni'];
$judul_info_alumni=$_POST['judul_info_alumni'];
$isi_info_alumni=($_POST['isi_info_alumni']);
$pengirim=($_POST['pengirim']);
$jam_posting=($_POST['jam_posting']);
$tanggal_posting=($_POST['tanggal_posting']);
if (isset($_POST['tambah'])){
$query="INSERT INTO tb_info_alumni (id_info_alumni,judul_info_alumni,isi_info_alumni,pengirim,posttime,postdate) 
values('','$judul_info_alumni','$isi_info_alumni','$pengirim','$jam_posting','$tanggal_posting')"or die(mysql_error());
$tambah=mysql_query($query);			
	if($query){
			?><script language="JavaScript">
			alert('Info alumni berhasil di tambahkan !');
			document.location='page.php?pg=info-alumni';
		</script><?php
		}	
}
else if ($_POST['update']){
$ubah = mysql_query("UPDATE tb_info_alumni SET  id_info_alumni='$id_info_alumni',judul_info_alumni='$judul_info_alumni',
isi_info_alumni='$isi_info_alumni',
pengirim='$pengirim',
posttime='$jam_posting',
postdate='$tanggal_posting'
 where id_info_alumni='$id_info_alumni'")or die(mysql_error());
if($ubah){		
?>
			<script language="JavaScript">
			alert('Info alumni berhasil di ubah !');
			document.location='page.php?pg=info-alumni';
		</script>
<?php
		}
}
else if ($_GET['hapus']){
$id_info_alumni = $_GET['hapus'];
$del="DELETE FROM tb_info_alumni where id_info_alumni='$id_info_alumni'";
  $del= mysql_query($del);
if($del){
			?><script language="JavaScript">
			alert('Info alumni berhasil di hapus !');
			document.location='page.php?pg=info-alumni';
		</script><?php
		}
}
header("location:page.php?pg=info-alumni");
?>