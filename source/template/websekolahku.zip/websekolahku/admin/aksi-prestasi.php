<?php
include ('koneksi/koneksi.php');
$id_prestasi=$_POST['id_prestasi'];
$nama_prestasi=$_POST['nama_prestasi'];
$isi_prestasi=($_POST['isi_prestasi']);
$keterangan=($_POST['keterangan']);
if (isset($_POST['tambah'])){
$query="INSERT INTO tb_prestasi (id_prestasi,nama_prestasi,isi_prestasi,keterangan) 
values('','$nama_prestasi','$isi_prestasi','$keterangan')"or die(mysql_error());
$tambah=mysql_query($query);			
	if($query){
			?><script language="JavaScript">
			alert('Prestasi berhasil di tambahkan !');
			document.location='page.php?pg=prestasi';
		</script><?php
		}	
}
else if ($_POST['update']){
$ubah = mysql_query("UPDATE tb_prestasi SET  id_prestasi='$id_prestasi',nama_prestasi='$nama_prestasi',
isi_prestasi='$isi_prestasi',
keterangan='$keterangan'
 where id_prestasi='$id_prestasi'")or die(mysql_error());
if($ubah){		
?>
			<script language="JavaScript">
			alert('Prestasi berhasil di ubah !');
			document.location='page.php?pg=prestasi';
		</script>
<?php
		}
}
else if ($_GET['hapus']){
$id_prestasi = $_GET['hapus'];
$del="DELETE FROM tb_prestasi where id_prestasi='$id_prestasi'";
  $del= mysql_query($del);
if($del){
			?><script language="JavaScript">
			alert('Data Prestasi berhasil di hapus !');
			document.location='page.php?pg=prestasi';
		</script><?php
		}
}
header("location:page.php?pg=prestasi");
?>