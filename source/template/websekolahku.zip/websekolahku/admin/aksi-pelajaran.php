<?php
include ('koneksi/koneksi.php');
$id_pelajaran=$_POST['id_pelajaran'];
$nama_mata_pelajaran=$_POST['nama_mata_pelajaran'];
$jenis_mata_pelajaran=($_POST['jenis_mata_pelajaran']);
if (isset($_POST['tambah'])){
$query="INSERT INTO tb_pelajaran (id_pelajaran,nama_mata_pelajaran,jenis_mata_pelajaran) values('','$nama_mata_pelajaran','$jenis_mata_pelajaran')"or die(mysql_error());
$tambah=mysql_query($query);			
	if($query){
			?><script language="JavaScript">
			alert('Mata pelajaran berhasil di tambahkan !');
			document.location='page.php?pg=pelajaran';
		</script><?php
		}	
}
else if ($_POST['update']){
$ubah = mysql_query("UPDATE tb_pelajaran SET nama_mata_pelajaran='$nama_mata_pelajaran',jenis_mata_pelajaran='$jenis_mata_pelajaran' where id_pelajaran='$id_pelajaran'")or die(mysql_error());
if($ubah){		
?>
			<script language="JavaScript">
			alert('Mata pelajaran berhasil di ubah !');
			document.location='page.php?pg=pelajaran';
		</script>
<?php
		}
}
else if ($_GET['hapus']){
$id_pelajaran = $_GET['hapus'];
$del="DELETE FROM tb_pelajaran where id_pelajaran='$id_pelajaran'";
  $del= mysql_query($del);
if($del){
			?><script language="JavaScript">
			alert('Mata pelajaran berhasil di hapus !');
			document.location='page.php?pg=pelajaran';
		</script><?php
		}
}
header("location:page.php?pg=pelajaran");
?>