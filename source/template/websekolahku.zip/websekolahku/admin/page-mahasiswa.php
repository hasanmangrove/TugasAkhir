<?php if (isset($_SESSION['username'])){ ?> 
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SIMPENAN | Data Mahasiswa</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
	<?php include('header.php'); ?>
      <!-- Left side column. contains the logo and sidebar -->
	<?php include ('menu-left.php'); ?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <?php include ('breadcrumbs.php'); ?>
		<!-- Main content -->
<?php
include ('koneksi/koneksi.php');
if($_SESSION['leveluser']==0){
//*********** Menampilkan Data dari tabel user ***********//
$daftar=mysql_query("select * from tb_mahasiswa order by nama_mahasiswa Asc");
}
//else if($_SESSION['leveluser']==1 OR $_SESSION['leveluser']==2) {
//$pengguna=$_SESSION['namauser'];
//*********** Menampilkan Data dari tabel user ***********//
//$daftar=mysql_query("select * from user where Username='$pengguna'order by Level Asc");
 //}
 ?>
 <?php
 if ($_GET['id_mahasiswa']){
 $id = $_GET['id_mahasiswa'];
							$query=mysql_query("SELECT * FROM tb_mahasiswa where id_mahasiswa='$id'")or die(mysql_error());
							while($row=mysql_fetch_array($query)){
							$id=$row['id_mahasiswa'];
							?>	
		 <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                  <li class="active"><a href="#fa-icons" data-toggle="tab">Edit Data Mahasiswa</a></li>
                </ul>
                <div class="tab-content">
				<div class="box">
                <div class="box-header with-border">
                  <h3 class="box-title">Formulir Edit Data Mahasiswa</h3>
                </div
				<!-- form start -->
                <form action="aksi-mahasiswa.php" enctype="multipart/form-data"  method="POST" role="form">
                  <div class="box-body">
				  <table width="100%">
				  <tr>
					<td width="30%">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Nomor Registrasi</label>
					  <input type="hidden" name="id" value="<?php echo $row['id_mahasiswa'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                      <input type="text" name="ednomor_registrasi" value="<?php echo $row['nomor_registrasi'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
					<td width="50%" colspan="2">
					<div class="form-group">
                      <label for="exampleInputEmail1">Nama Mahasiswa</label>
					  <input type="text" name="ednama_mahasiswa" value="<?php echo $row['nama_mahasiswa'] ?>" style="width: 100%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
				  </tr>
				  <tr>
					<td width="30%">
					<div class="form-group">
                      <label for="exampleInputEmail1">Tempat Lahir</label>
					  <input type="text" name="edtempat_lahir" value="<?php echo $row['tempat_lahir'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
					<td width="50%" colspan="2">
					<div class="form-group">
                      <label for="exampleInputEmail1">Tanggal Lahir</label>
					  <input type="date" name="edtanggal_lahir" value="<?php echo $row['tanggal_lahir'] ?>" style="width: 40%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
				  </tr>
				  <tr>
					<td width="30%">
					<div class="form-group">
                    <label>Jenis Kelamin</label>
                    <select name="edjenis_kelamin" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<?php 
					$jk=$row['tanggal_lahir'];
					if ($jk=='Laki-Laki'){echo"<option value='Laki-Laki' selected>Laki-Laki</option><option value='Perempuan'>Perempuan</option>"; }
					else {echo"<option value='Laki-Laki'>Laki-Laki</option><option value='Perempuan' selected>Perempuan</option>";}
					?>
                    </select>
                  </div>
				  </td>
				  <td width="50%" colspan="2">
				  <div class="form-group">
                    <label>Agama</label>
                    <select name="ednama_agama" class="form-control select2" style="width: 100%;">
					<option value="">Pilihan</option>
					<?php 
					$agama=$row['agama'];
					if ($agama=='Islam'){echo"
					<option value='Islam' selected>Islam</option>
					<option value='Kristen'>Kristen</option>
					<option value='Hindu'>Hindu</option>
					<option value='Budha'>Budha</option>
					<option value='Khatolik'>Khatolik</option>"; }
					else if ($agama=='Kristen'){ echo"
					<option value='Islam'>Islam</option>
					<option value='Kristen' selected>Kristen</option>
					<option value='Hindu'>Hindu</option>
					<option value='Budha'>Budha</option>
					<option value='Khatolik'>Khatolik</option>";}
					else if ($agama=='Hindu'){echo"
					<option value='Islam'>Islam</option>
					<option value='Kristen'>Kristen</option>
					<option value='Hindu' selected>Hindu</option>
					<option value='Budha'>Budha</option>
					<option value='Khatolik'>Khatolik</option>";}
					else if ($agama=='Budha'){echo"
					<option value='Islam'>Islam</option>
					<option value='Kristen'>Kristen</option>
					<option value='Hindu'>Hindu</option>
					<option value='Budha' selected>Budha</option>
					<option value='Khatolik'>Khatolik</option>";}
					else if ($agama=='Khatolik'){echo"
					<option value='Islam'>Islam</option>
					<option value='Kristen'>Kristen</option>
					<option value='Hindu'>Hindu</option>
					<option value='Budha'>Budha</option>
					<option value='Khatolik' selected>Khatolik</option>";}?>
                    </select>
                  </div>
				  </td>
				 <tr>
				  <td width="30%">
				  <div class="form-group">
                    <label>Suku</label>
                    <select name="ednama_suku" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<?php 
					$nama_suku=$row['suku'];
					if ($nama_suku=='Bugis'){echo"
					<option value='Bugis' selected>Bugis</option>
					<option value='Buton'>Buton</option>
					<option value='Bali'>Bali</option>
					<option value='Jawa'>Jawa</option>
					<option value='Muna'>Muna</option>
					<option value='Tolaki'>Tolaki</option>
					<option value='Lainnya'>Lainnya</option>";}
					else if ($nama_suku=='Buton'){echo"
					<option value='Bugis'>Bugis</option>
					<option value='Buton'selected>Buton</option>
					<option value='Bali'>Bali</option>
					<option value='Jawa'>Jawa</option>
					<option value='Muna'>Muna</option>
					<option value='Tolaki'>Tolaki</option>
					<option value='Lainnya'>Lainnya</option>";}
					else if ($nama_suku=='Bali'){echo"
					<option value='Bugis'>Bugis</option>
					<option value='Buton'>Buton</option>
					<option value='Bali'selected>Bali</option>
					<option value='Jawa'>Jawa</option>
					<option value='Muna'>Muna</option>
					<option value='Tolaki'>Tolaki</option>
					<option value='Lainnya'>Lainnya</option>";}
					else if ($nama_suku=='Jawa'){echo"
					<option value='Bugis'>Bugis</option>
					<option value='Buton'selected>Buton</option>
					<option value='Bali'>Bali</option>
					<option value='Jawa'selected>Jawa</option>
					<option value='Muna'>Muna</option>
					<option value='Tolaki'>Tolaki</option>
					<option value='Lainnya'>Lainnya</option>";}
					else if ($nama_suku=='Muna'){echo"
					<option value='Bugis'>Bugis</option>
					<option value='Buton'selected>Buton</option>
					<option value='Bali'>Bali</option>
					<option value='Jawa'>Jawa</option>
					<option value='Muna'selected>Muna</option>
					<option value='Tolaki'>Tolaki</option>
					<option value='Lainnya'>Lainnya</option>";}
					else if ($nama_suku=='Tolaki'){echo"
					<option value='Bugis'>Bugis</option>
					<option value='Buton'selected>Buton</option>
					<option value='Bali'>Bali</option>
					<option value='Jawa'>Jawa</option>
					<option value='Muna'>Muna</option>
					<option value='Tolaki'selected>Tolaki</option>
					<option value='Lainnya'>Lainnya</option>";}
					else if ($nama_suku=='Lainnya'){echo"
					<option value='Bugis'>Bugis</option>
					<option value='Buton'selected>Buton</option>
					<option value='Bali'>Bali</option>
					<option value='Jawa'>Jawa</option>
					<option value='Muna'>Muna</option>
					<option value='Tolaki'>Tolaki</option>
					<option value='Lainnya'selected>Lainnya</option>";}
					?>
                    </select>
                  </div>
				  </td>
				  <td width="50%" colspan="2">
				  <div class="form-group">
                    <label>Kebangsaan</label>
                    <select name="ednama_kebangsaan" class="form-control select2" style="width: 100%;">
					<?php $bangsa=$row['kebangsaan'];
					if ($bangsa=='WNI'){echo"<option value='WNI' selected>WNI</option><option value='WNA'>WNA</option>";}
					else if ($bangsa=='WNA') {echo "<option value='WNI'>WNI</option><option value='WNA'selected>WNA</option>";}?>
                    </select>
                  </div>
				  </td>
				 </tr>
				 <tr>
				 <td width="30%">
					<div class="form-group">
                    <label>Status Mahasiswa</label>
                    <select name="edstatus_mahasiswa" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<?php $stm=$row['status_mahasiswa'];
					if ($stm=='Kawin'){echo"
					<option value='Kawin'selected>Kawin</option>
					<option value='Belum Kawin'>Belum Kawin</option>";}
					else if ($stm=='Belum Kawin'){echo"
					<option value='Kawin'>Kawin</option>
					<option value='Belum Kawin' selected>Belum Kawin</option>";}
					?>
                    </select>
                  </div>
				 </td>
				 <td width="30%">
					<div class="form-group">
                      <label for="exampleInputPhone">Nomor Telepon/HP</label>
					  <input type="phone" name="ednomor_hp" value="<?php echo $row['nomor_hp'] ?>" style="width: 80%;" class="form-control" id="exampleInputPhone">
                    </div>
				</td>
				<td width="40%">
					<div class="form-group">
                      <label for="exampleInputEmail">Email</label>
					  <input type="email" name="edemail" value="<?php echo $row['email'] ?>" style="width: 80%;" class="form-control" id="exampleInputEmail">
                    </div>
					</td>
				 </tr>
				 </table>
				 <hr>
				<table width="100%">
				  <tr>
					<td width="40%">
					<div class="form-group">
                    <label>Pilihan Jurusan</label>
                    <select name="edpilihan_jurusan" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<?php $jurusan=$row['pilihan_jurusan1'];
					if ($jurusan=='Sistem Informasi') {echo"
					<option value='Sistem Informasi' selected>Sistem Informasi</option>
					<option value='Sistem Komputer'>Sistem Komputer</option>";}
					else if ($jurusan=='Sistem Komputer') {echo"
					<option value='Sistem Informasi'>Sistem Informasi</option>
					<option value='Sistem Komputer'selected>Sistem Komputer</option>";}
					?>
                    </select>
                  </div>
				  </td>
				  <td width="40%">
				  <div class="form-group">
                    <label>Pilihan Kelas</label>
                    <select name="edpilihan_kelas" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<?php $kelas=$row['pilihan_kelas'];
					if ($kelas=='Reguler') {echo"
					<option value='Reguler' selected>Reguler</option>
					<option value='Ekstensi'>Ekstensi</option>";}
					else if ($kelas=='Ekstensi') {echo"
					<option value='Reguler'>Reguler</option>
					<option value='Ekstensi'selected>Ekstensi</option>";}
					?>
                    </select>
                  </div>
				  </td>
				  </tr>   
				  <tr>
					<td width="40%">
                    <div class="form-group">
                      <label for="exampleInputText">Nama Pekerjaan</label>
					  <input type="text" name="ednama_pekerjaan" value="<?php echo $row['nama_pekerjaan'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
					<td width="40%">
					<div class="form-group">
                      <label for="exampleInputEmail1">Nama Instansi</label>
					  <input type="text" name="ednama_instansi" value="<?php echo $row['nama_instansi'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
				  </tr>
				  <tr>
					<td width="40%">
                    <div class="form-group">
                      <label for="exampleInputText">Nama Pangkat</label>
					  <input type="text" name="ednama_pangkat" value="<?php echo $row['nama_pangkat'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
					<td width="40%">
					<div class="form-group">
                      <label for="exampleInputEmail1">Nama Jabatan</label>
					  <input type="text" name="ednama_jabatan" value="<?php echo $row['nama_jabatan'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
				  </tr>
				  <tr>
					<td width="30%">
					<div class="form-group">
                      <label for="exampleInputEmail1">Alamat Instansi</label>
					  <input type="text" name="edalamat_instansi" value="<?php echo $row['alamat_instansi'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
				  </tr>
				 </table><hr>
				 <table width="100%">
				  <tr>
					<td width="40%">
					 <div class="form-group">
                      <label for="exampleInputText">Asal Sekolah</label>
					  <input type="text" name="edasal_sekolah" value="<?php echo $row['asal_sekolah'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  <td width="40%">
				  <div class="form-group">
                    <label>Jurusan Sekolah</label>
                    <select name="edjurusan_sekolah" class="form-control select2" style="width: 90%;">
					<option value="<?php echo $row['jurusan_sekolah'] ?>"><?php echo $row['jurusan_sekolah'] ?></option>
					<option value="Teknik Komputer dan Jaringan">Teknik Komputer dan Jaringan</option>
					<option value="Adminsitrasi Perkantoran">Adminsitrasi Perkantoran</option>
                    <option value="Rekayasa Perangkat Lunak">Rekayasa Perangkat Lunak</option>
					<option value="Desain Komunikasi Visual">Desain Komunikasi Visual</option>
					<option value="Kriya Tekstil">Kriya Tekstil</option>
					<option value="Tata Busana">Tata Busana</option>
					<option value="Multimedia">Multimedia</option>
					<option value="Kriya Kayu">Kriya Kayu</option>
					<option value="Automotip">Automotip</option>
					<option value="Tata Boga">Tata Boga</option>
					<option value="IPA">IPA</option>
					<option value="IPS">IPS</option>
					</select>
                  </div>
				  </td>
				  </tr>   
				  <tr>
					<td width="40%">
                    <div class="form-group">
                    <label>Tahun Masuk</label>
                    <select name="edtahun_masuk" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<?php
					for($i=date('Y'); $i>=date('Y')-32; $i-=1){
					If ($i==$row['tahun_masuk']) { echo"<option value='$i' selected> $i </option>"; }
					Else { echo"<option value='$i'> $i </option>"; }
					}?>
					</select>
                   </div>
					</td>
					<td width="40%">
					<div class="form-group">
                    <label>Tahun Keluar</label>
                    <select name="edtahun_lulus" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<?php
					for($y=date('Y'); $y>=date('Y')-32; $y-=1){
					If ($y==$row['tahun_lulus']) { echo"<option value='$y' selected> $y </option>"; }
					Else { echo"<option value='$y'> $y </option>"; }
					}?>
					</select>
                   </div>
					</td>
				  </tr>
				  <tr>
					<td width="40%">
                    <div class="form-group">
                      <label for="exampleInputText">Pengalaman Organisasi</label>
					  <input type="text" name="edpengalaman_organisasi" value="<?php echo $row['pengalaman_organisasi'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
					<td width="40%">
					<div class="form-group">
                      <label for="exampleInputEmail1">Pengalaman Kursus</label>
					  <input type="text" name="edpengalaman_kursus" value="<?php echo $row['pengalaman_kursus'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
				  </tr>
				  <tr>
					<td width="30%">
					<div class="form-group">
                      <label for="exampleInputEmail1">Nama Keterampilan</label>
					  <input type="text" name="ednama_keterampilan" value="<?php echo $row['nama_keterampilan'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
				  </tr>
				 </table><hr>
				  <table width="100%">
				  <tr>
					<td width="40%">
					 <div class="form-group">
                      <label for="exampleInputText">Nama Ayah</label>
					  <input type="text" name="ednama_ayah" value="<?php echo $row['nama_ayah'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  <td width="40%">
				  <div class="form-group">
                      <label for="exampleInputText">Nama Ibu</label>
					  <input type="text" name="ednama_ibu" value="<?php echo $row['nama_ibu'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  </tr>  
				  <tr>
					<td width="40%">
					 <div class="form-group">
                      <label for="exampleInputText">Pekerjaan Ayah</label>
					  <input type="text" name="edpekerjaan_ayah" value="<?php echo $row['pekerjaan_ayah'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  <td width="40%">
				  <div class="form-group">
                      <label for="exampleInputText">Pekerjaan Ibu</label>
					  <input type="text" name="edpekerjaan_ibu" value="<?php echo $row['pekerjaan_ibu'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  </tr> 
				  <tr>
					<td width="40%">
					 <div class="form-group">
                      <label for="exampleInputText">Penghasilan Ayah</label>
					  <input type="text" name="edpenghasilan_ayah" value="<?php echo $row['penghasilan_ayah'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  <td width="40%">
				  <div class="form-group">
                      <label for="exampleInputText">Penghasilan Ibu</label>
					  <input type="text" name="edpenghasilan_ibu" value="<?php echo $row['penghasilan_ibu'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  </tr>  
				  <tr>
					<td width="40%">
					 <div class="form-group">
                      <label for="exampleInputText">Nama Wali</label>
					  <input type="text" name="ednama_wali" value="<?php echo $row['nama_wali'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  <td width="40%">
				  <div class="form-group">
				  <label>Keterangan Ortu/Wali</label>
                    <select name="edketerangan_wali" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<?php echo $keterangan=$row['keterangan_wali'];
					if ($keterangan=='Masih Hidup') { echo"
					<option value='Masih Hidup' selected>Masih Hidup</option>
					<option value='Meninggal Dunia'>Meninggal Dunia</option>";}
					else if ($keterangan=='Meninggal Dunia') { echo"
					<option value='Masih Hidup'>Masih Hidup</option>
					<option value='Meninggal Dunia'selected>Meninggal Dunia</option>";}
					?>
					</select>
				  </div>
				  </td>
				  </tr>  
				  <tr>
					<td width="40%">
					 <div class="form-group">
                      <label for="exampleInputText">Alamat Ortu/Wali</label>
					  <input type="text" name="edalamat_wali" value="<?php echo $row['alamat_wali'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  <td width="40%">
				  <div class="form-group">
                      <label for="exampleInputText">Kontak Ortu/Wali</label>
					  <input type="text" name="edkontak_wali" value="<?php echo $row['kontak_wali'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  </tr> 				  
				  <tr>
					<td width="40%">
                    <div class="form-group">
                    <label>Status Tempat Tinggal Mahasiswa</label>
                    <select name="edstatus_tinggal" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<?php echo $stt=$row['status_tinggal']; 
					if ($stt=='Kontrak'){ echo"
					<option value='Kontrak'selected>Kontrak</option>
					<option value='Rumah Sendiri'>Rumah Sendiri</option>
					<option value='Tinggal Sama Keluarga'>Tinggal Sama Keluarga</option>";}
					else if ($stt=='Rumah Sendiri'){ echo"
					<option value='Kontrak'>Kontrak</option>
					<option value='Rumah Sendiri'selected>Rumah Sendiri</option>
					<option value='Tinggal Sama Keluarga'>Tinggal Sama Keluarga</option>";}
					else if ($stt=='Tinggal Sama Keluarga'){ echo"
					<option value='Kontrak'>Kontrak</option>
					<option value='Rumah Sendiri'>Rumah Sendiri</option>
					<option value='Tinggal Sama Keluarga'selected>Tinggal Sama Keluarga</option>";}
					?>
					</select>
                   </div>
					</td>
					<td width="40%">
					<div class="form-group">
                      <label for="exampleInputText">Photo</label>
					  <input type="file" name="edphoto" value="<?php echo $row['photo'] ?>" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
				  </tr>
				  <tr>
					<td width="40%">
                    <div class="form-group">
                    <label>Status Aktif</label>
                    <select name="edstatus" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<?php $sm=$row['status'];
					if ($sm==0) {echo"
					<option value='0'selected>MABA</option>
					<option value='1'>Mahasiswa</option>
					<option value='2'>Alumni</option>";}
					else if ($sm==1) {echo"
					<option value='0'>MABA</option>
					<option value='1'selected>Mahasiswa</option>
					<option value='2'>Alumni</option>";}
					else if ($sm==2) {echo"
					<option value='0'>MABA</option>
					<option value='1'>Mahasiswa</option>
					<option value='2'selected>Alumni</option>";}
					?>
					</select>
                    </div>
					</td>
				  </tr>
				  <tr>
					<td width="40%">
                    <div class="form-group">
                    <label>Sumber Informasi Pendaftaran</label>
                    <select name="edsumber_informasi" class="form-control select2" style="width: 90%;">
					<option value="<?php echo $row['sumber_informasi'] ?>"><?php echo $row['sumber_informasi'] ?></option>
					<option value="Teman">Teman</option>
					<option value="Keluarga">Keluarga</option>
					<option value="Orang Tua">Orang Tua</option>
					<option value="Media Cetak">Media Cetak</option>
					<option value="Media Radio">Media Radio</option>
					<option value="Media Sosial">Media Sosial</option>
					<option value="Media Televisi">Media Televisi</option>
					</select>
                    </div>
					</td>
				  </tr>
				 </table>
                  <div class="box-footer">
                    <input type="submit" name="update" class="btn btn-info btn-flat glyphicon glyphicon-floppy-save" value="Update">
                  </div>
                </form>
                  </div><!-- /#ion-icons -->
                </div><!-- /.tab-content -->
              </div><!-- /.nav-tabs-custom -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
<?php } } else { ?>
		 <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                  <li class="active"><a href="#fa-icons" data-toggle="tab">Tampilkan Daftar Mahasiswa</a></li>
                  <li><a href="#glyphicons" data-toggle="tab">Tambah Mahasiswa</a></li>
                </ul>
                <div class="tab-content">
                  <!-- Font Awesome Icons -->
                  <div class="tab-pane active" id="fa-icons">
               <div class="box">
                <div class="box-body scrolltable">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Nomor Registrasi</th>
                        <th>Nama Mahasiswa</th>
						<th>Tempat/Tanggal Lahir</th>
                        <th>Jurusan</th>
						<th>Jurusan</th>
						<th>Jurusan</th>
						<th>Jurusan</th>
						<th>Jurusan</th>
						<th>Jurusan</th>
						<th>Jurusan</th>
						<th>Jurusan</th>
						<th>Jurusan</th>
						<th>Jurusan</th>
						<th>Jurusan</th>
						<th>Jurusan</th>
						<th>Jurusan</th>
						<th>Jurusan</th>
                        <?php if($_SESSION['lvl']==0){echo"<th>Aksi</th>";}?>
                      </tr>
                    </thead>
                    <tbody>
<?php 
$counter = 1; 
while ($dt=mysql_fetch_array($daftar)){
$level_user=$dt['Level'];
echo "
			<tr>
				<td>$counter</td>
				<td class='center'>".$dt['nomor_registrasi']."</td>
				<td class='center'>".$dt['nama_mahasiswa']."</td>
				<td class='center'>".$dt['tempat_lahir'].",".date('d-m-Y',strtotime($dt['tanggal_lahir']))."</td>
				<td class='center'>".$dt['pilihan_jurusan1']."</td>
				<td class='center'>".$dt['pilihan_jurusan1']."</td>
				<td class='center'>".$dt['pilihan_jurusan1']."</td>
				<td class='center'>".$dt['pilihan_jurusan1']."</td>
				<td class='center'>".$dt['pilihan_jurusan1']."</td>
				<td class='center'>".$dt['pilihan_jurusan1']."</td>
				<td class='center'>".$dt['pilihan_jurusan1']."</td>
				<td class='center'>".$dt['pilihan_jurusan1']."</td>
				<td class='center'>".$dt['pilihan_jurusan1']."</td>
				<td class='center'>".$dt['pilihan_jurusan1']."</td>
				<td class='center'>".$dt['pilihan_jurusan1']."</td>
				<td class='center'>".$dt['pilihan_jurusan1']."</td>
				<td class='center'>".$dt['pilihan_jurusan1']."</td>
				<td class='center'>".$dt['pilihan_jurusan1']."</td>";
				if($_SESSION['lvl']==0){
				echo"<td class='center'><i class='glyphicon glyphicon-edit icon-white'></i><a href='page.php?id_mahasiswa=".$dt['id_mahasiswa']."'>Edit </a> <i class='glyphicon glyphicon-trash icon-white'>  </i>";?>
				<a onClick="return confirm('Apakah Anda yakin menghapus nama mahasiswa ini ?')"<?php echo"href='aksi-mahasiswa.php?hapus=".$dt['id_mahasiswa']."'>Hapus</a></td>";	} ?> 
			</tr>
<?php $counter ++; } ?>
                    </tbody>
                  </table>
                </div>
              </div>
              </div>
              <div class="tab-pane" id="glyphicons">
              <div class="box">
                <div class="box-header with-border">
                  <h3 class="box-title">Formulir Input Data Mahasiswa</h3>
                </div
				<!-- form start -->
                <form action="aksi-mahasiswa.php" enctype="multipart/form-data" method="POST" role="form">
                  <div class="box-body">
				  <table width="100%">
				  <tr>
					<td width="30%">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Nomor Registrasi</label>
					  <input type="text" name="nomor_registrasi" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
					<td width="50%" colspan="2">
					<div class="form-group">
                      <label for="exampleInputEmail1">Nama Mahasiswa</label>
					  <input type="text" name="nama_mahasiswa" value="" style="width: 100%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
				  </tr>
				  <tr>
					<td width="30%">
					<div class="form-group">
                      <label for="exampleInputEmail1">Tempat Lahir</label>
					  <input type="text" name="tempat_lahir" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
					<td width="50%" colspan="2">
					<div class="form-group">
                      <label for="exampleInputEmail1">Tanggal Lahir</label>
					  <input type="date" name="tanggal_lahir" value="" style="width: 40%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
				  </tr>
				  <tr>
					<td width="30%">
					<div class="form-group">
                    <label>Jenis Kelamin</label>
                    <select name="jenis_kelamin" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<option value="Laki-Laki">Laki-Laki</option>
					<option value="Perempuan">Perempuan</option>
                    </select>
                  </div>
				  </td>
				  <td width="50%" colspan="2">
				  <div class="form-group">
                    <label>Agama</label>
                    <select name="nama_agama" class="form-control select2" style="width: 100%;">
					<option value="">Pilihan</option>
					<option value="Islam">Islam</option>
					<option value="Kristen">Kristen</option>
					<option value="Hindu">Hindu</option>
					<option value="Budha">Budha</option>
					<option value="Khatolik">Khatolik</option>
                    </select>
                  </div>
				  </td>
				 <tr>
				  <td width="30%">
				  <div class="form-group">
                    <label>Suku</label>
                    <select name="nama_suku" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<option value="Bugis">Bugis</option>
					<option value="Buton">Buton</option>
					<option value="Bali">Bali</option>
					<option value="Jawa">Jawa</option>
					<option value="Muna">Muna</option>
					<option value="Tolaki">Tolaki</option>
					<option value="Lainnya">Lainnya</option>
                    </select>
                  </div>
				  </td>
				  <td width="50%" colspan="2">
				  <div class="form-group">
                    <label>Kebangsaan</label>
                    <select name="nama_kebangsaan" class="form-control select2" style="width: 100%;">
					<option value="WNI">WNI</option>
					<option value="WNA">WNA</option>
                    </select>
                  </div>
				  </td>
				 </tr>
				 <tr>
				 <td width="30%">
					<div class="form-group">
                    <label>Status Mahasiswa</label>
                    <select name="status_mahasiswa" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<option value="Kawin">Kawin</option>
					<option value="Belum Kawin">Belum Kawin</option>
                    </select>
                  </div>
				 </td>
				 <td width="30%">
					<div class="form-group">
                      <label for="exampleInputPhone">Nomor Telepon/HP</label>
					  <input type="phone" name="nomor_hp" value="" style="width: 80%;" class="form-control" id="exampleInputPhone">
                    </div>
				</td>
				<td width="40%">
					<div class="form-group">
                      <label for="exampleInputEmail">Email</label>
					  <input type="email" name="email" value="" style="width: 80%;" class="form-control" id="exampleInputEmail">
                    </div>
					</td>
				 </tr>
				 </table>
				 <hr>
				<table width="100%">
				  <tr>
					<td width="40%">
					<div class="form-group">
                    <label>Pilihan Jurusan</label>
                    <select name="pilihan_jurusan" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<option value="Sistem Informasi">Sistem Informasi</option>
					<option value="Sistem Komputer">Sistem Komputer</option>
                    </select>
                  </div>
				  </td>
				  <td width="40%">
				  <div class="form-group">
                    <label>Pilihan Kelas</label>
                    <select name="pilihan_kelas" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<option value="Reguler">Reguler</option>
					<option value="Ekstensi">Ekstensi</option>
                    </select>
                  </div>
				  </td>
				  </tr>   
				  <tr>
					<td width="40%">
                    <div class="form-group">
                      <label for="exampleInputText">Nama Pekerjaan</label>
					  <input type="text" name="nama_pekerjaan" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
					<td width="40%">
					<div class="form-group">
                      <label for="exampleInputEmail1">Nama Instansi</label>
					  <input type="text" name="nama_instansi" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
				  </tr>
				  <tr>
					<td width="40%">
                    <div class="form-group">
                      <label for="exampleInputText">Nama Pangkat</label>
					  <input type="text" name="nama_pangkat" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
					<td width="40%">
					<div class="form-group">
                      <label for="exampleInputEmail1">Nama Jabatan</label>
					  <input type="text" name="nama_jabatan" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
				  </tr>
				  <tr>
					<td width="30%">
					<div class="form-group">
                      <label for="exampleInputEmail1">Alamat Instansi</label>
					  <input type="text" name="alamat_instansi" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
				  </tr>
				 </table><hr>
				 <table width="100%">
				  <tr>
					<td width="40%">
					 <div class="form-group">
                      <label for="exampleInputText">Asal Sekolah</label>
					  <input type="text" name="asal_sekolah" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  <td width="40%">
				  <div class="form-group">
                    <label>Jurusan Sekolah</label>
                    <select name="jurusan_sekolah" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<option value="Teknik Komputer dan Jaringan">Teknik Komputer dan Jaringan</option>
					<option value="Adminsitrasi Perkantoran">Adminsitrasi Perkantoran</option>
                    <option value="Rekayasa Perangkat Lunak">Rekayasa Perangkat Lunak</option>
					<option value="Desain Komunikasi Visual">Desain Komunikasi Visual</option>
					<option value="Kriya Tekstil">Kriya Tekstil</option>
					<option value="Tata Busana">Tata Busana</option>
					<option value="Multimedia">Multimedia</option>
					<option value="Kriya Kayu">Kriya Kayu</option>
					<option value="Automotip">Automotip</option>
					<option value="Tata Boga">Tata Boga</option>
					<option value="IPA">IPA</option>
					<option value="IPS">IPS</option>
					</select>
                  </div>
				  </td>
				  </tr>   
				  <tr>
					<td width="40%">
                    <div class="form-group">
                    <label>Tahun Masuk</label>
                    <select name="tahun_masuk" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<?php for($i=date('Y'); $i>=date('Y')-32; $i-=1){ echo"<option value='$i'> $i </option>";}?>
					</select>
                   </div>
					</td>
					<td width="40%">
					<div class="form-group">
                    <label>Tahun Keluar</label>
                    <select name="tahun_lulus" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<?php for($i=date('Y'); $i>=date('Y')-32; $i-=1){ echo"<option value='$i'> $i </option>";}?>
					</select>
                   </div>
					</td>
				  </tr>
				  <tr>
					<td width="40%">
                    <div class="form-group">
                      <label for="exampleInputText">Pengalaman Organisasi</label>
					  <input type="text" name="pengalaman_organisasi" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
					<td width="40%">
					<div class="form-group">
                      <label for="exampleInputEmail1">Pengalaman Kursus</label>
					  <input type="text" name="pengalaman_kursus" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
				  </tr>
				  <tr>
					<td width="30%">
					<div class="form-group">
                      <label for="exampleInputEmail1">Nama Keterampilan</label>
					  <input type="text" name="nama_keterampilan" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
				  </tr>
				 </table><hr>
				  <table width="100%">
				  <tr>
					<td width="40%">
					 <div class="form-group">
                      <label for="exampleInputText">Nama Ayah</label>
					  <input type="text" name="nama_ayah" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  <td width="40%">
				  <div class="form-group">
                      <label for="exampleInputText">Nama Ibu</label>
					  <input type="text" name="nama_ibu" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  </tr>  
				  <tr>
					<td width="40%">
					 <div class="form-group">
                      <label for="exampleInputText">Pekerjaan Ayah</label>
					  <input type="text" name="pekerjaan_ayah" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  <td width="40%">
				  <div class="form-group">
                      <label for="exampleInputText">Pekerjaan Ibu</label>
					  <input type="text" name="pekerjaan_ibu" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  </tr> 
				  <tr>
					<td width="40%">
					 <div class="form-group">
                      <label for="exampleInputText">Penghasilan Ayah</label>
					  <input type="text" name="penghasilan_ayah" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  <td width="40%">
				  <div class="form-group">
                      <label for="exampleInputText">Penghasilan Ibu</label>
					  <input type="text" name="penghasilan_ibu" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  </tr>  
				  <tr>
					<td width="40%">
					 <div class="form-group">
                      <label for="exampleInputText">Nama Wali</label>
					  <input type="text" name="nama_wali" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  <td width="40%">
				  <div class="form-group">
				  <label>Keterangan Ortu/Wali</label>
                    <select name="keterangan_wali" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<option value="Masih Hidup">Masih Hidup</option>
					<option value="Meninggal Dunia">Meninggal Dunia</option>
					</select>
				  </div>
				  </td>
				  </tr>  
				  <tr>
					<td width="40%">
					 <div class="form-group">
                      <label for="exampleInputText">Alamat Ortu/Wali</label>
					  <input type="text" name="alamat_wali" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  <td width="40%">
				  <div class="form-group">
                      <label for="exampleInputText">Kontak Ortu/Wali</label>
					  <input type="text" name="kontak_wali" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
				  </td>
				  </tr> 				  
				  <tr>
					<td width="40%">
                    <div class="form-group">
                    <label>Status Tempat Tinggal Mahasiswa</label>
                    <select name="status_tinggal" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<option value="Kontrak">Kontrak</option>
					<option value="Rumah Sendiri">Rumah Sendiri</option>
					<option value="Tinggal Sama Keluarga">Tinggal Sama Keluarga</option>
					</select>
                   </div>
					</td>
					<td width="40%">
					<div class="form-group">
                      <label for="exampleInputText">Photo</label>
					  <input type="file" name="photo" value="" style="width: 90%;" class="form-control" id="exampleInputUsername">
                    </div>
					</td>
				  </tr>
				  <tr>
					<td width="40%">
                    <div class="form-group">
                    <label>Status Aktif</label>
                    <select name="status" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<option value="0">Calon MABA</option>
					<option value="1">Mahasiswa</option>
					<option value="2">Alumni</option>
					</select>
                    </div>
					</td>
				  </tr>
				  <tr>
					<td width="40%">
                    <div class="form-group">
                    <label>Sumber Informasi Pendaftaran</label>
                    <select name="sumber_informasi" class="form-control select2" style="width: 90%;">
					<option value="">Pilihan</option>
					<option value="Teman">Teman</option>
					<option value="Keluarga">Keluarga</option>
					<option value="Orang Tua">Orang Tua</option>
					<option value="Media Cetak">Media Cetak</option>
					<option value="Media Radio">Media Radio</option>
					<option value="Media Sosial">Media Sosial</option>
					<option value="Media Televisi">Media Televisi</option>
					</select>
                    </div>
					</td>
				  </tr>
				 </table>
                  <div class="box-footer">
                    <input type="submit" name="tambah" class="btn btn-info btn-flat glyphicon glyphicon-floppy-save" value="Simpan">
                  </div>
                </form>
                  </div><!-- /#ion-icons -->
                </div><!-- /.tab-content -->
              </div><!-- /.nav-tabs-custom -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
	<?php } ?>
      </div><!-- /.content-wrapper -->
    <?php include ('foter.php'); ?>
      <!-- Control Sidebar -->
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!-- DataTables -->
    <script src="plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="plugins/datatables/dataTables.bootstrap.min.js"></script>
    <!-- SlimScroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <!-- page script -->
    <script>
      $(function () {
        $("#example1").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>
  </body>
</html>
<?php } else  {
echo "<script language='javascript'>history.back();</script>"; }?>