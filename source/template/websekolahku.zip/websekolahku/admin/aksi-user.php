<?php
include ('koneksi/koneksi.php');
$id=$_POST['id'];
$user=$_POST['username'];
$password=md5($_POST['password']);
$level=$_POST['level'];
if ($_POST['tambah']){
$query="INSERT INTO user (Id_user,Username,Password,Level) values('','$user','$password','$level')"or die(mysql_error());
$tambah=mysql_query($query);			
	if($query){
			?><script language="JavaScript">
			alert('Data user berhasil di tambahkan !');
			document.location='page.php?pg=pengguna';
		</script><?php
		}	
}
else if ($_POST['update']){
$ubah = mysql_query("UPDATE user SET Username='$user',Password='$password',Level='$level' where Id_user='$id'")or die(mysql_error());
if($ubah){		
?>
			<script language="JavaScript">
			alert('Data berhasil di ubah !');
			document.location='page.php?pg=pengguna';
		</script>
<?php
		}
}
else if ($_GET['hapus']){
$pengguna = $_GET['hapus'];
$del="DELETE FROM user where Username='$pengguna'";
  $del= mysql_query($del);
if($del){
			?><script language="JavaScript">
			alert('Data berhasil di hapus !');
			document.location='page.php?pg=pengguna';
		</script><?php
		}
}
header("location:page.php?pg=pengguna");
?>