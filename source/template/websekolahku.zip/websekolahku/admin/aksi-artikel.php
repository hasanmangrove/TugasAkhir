<?php
include ('koneksi/koneksi.php');
$id_artikel=$_POST['id_artikel'];
$judul_artikel=$_POST['judul_artikel'];
$isi_artikel=($_POST['isi_artikel']);
$pengirim=($_POST['pengirim']);
$tanggal_posting=($_POST['tanggal_posting']);
$kategori=($_POST['kategori']);
if (isset($_POST['tambah'])){
$query="INSERT INTO tb_artikel (id_artikel,tanggal_posting,judul_artikel,isi_artikel,pengirim,id_kategori) 
values('','$tanggal_posting','$judul_artikel','$isi_artikel','$pengirim','$kategori')"or die(mysql_error());
$tambah=mysql_query($query);			
	if($query){
			?><script language="JavaScript">
			alert('Artikel berhasil di tambahkan !');
			document.location='page.php?pg=artikel';
		</script><?php
		}	
}
else if ($_POST['update']){
$ubah = mysql_query("UPDATE tb_artikel SET  id_artikel='$id_artikel',
tanggal_posting='$tanggal_posting',
judul_artikel='$judul_artikel',
isi_artikel='$isi_artikel',
pengirim='$pengirim',
id_kategori='$kategori'
 where id_artikel='$id_artikel'")or die(mysql_error());
if($ubah){		
?>
			<script language="JavaScript">
			alert('Artikel berhasil di ubah !');
			document.location='page.php?pg=artikel';
		</script>
<?php
		}
}
else if ($_GET['hapus']){
$id_artikel = $_GET['hapus'];
$del="DELETE FROM tb_artikel where id_artikel='$id_artikel'";
  $del= mysql_query($del);
if($del){
			?><script language="JavaScript">
			alert('Artikel berhasil di hapus !');
			document.location='page.php?pg=artikel';
		</script><?php
		}
}
header("location:page.php?pg=artikel");
?>