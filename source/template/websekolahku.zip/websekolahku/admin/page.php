<?php 
session_start(); 	
$page=$_GET['pg'];
if ($page=='home'){ include ("index2.php"); }
//*Menu Pengguna*//
$edit=$_GET['iduser'];	
if ($page=='pengguna'){ include ("data.php"); } 
if ($edit!=''){ include ("data.php"); }  
//Menu Kategori//
$ed_kategori=$_GET['id_kategori'];
if ($page=='kategori'){ include ("v_kategori.php"); } 
if ($ed_kategori!=''){ include ("v_kategori.php"); }
//Menu Jurusan//
$e_jurusan=$_GET['id_jurusan'];
if ($page=='jurusan'){ include ("page-jurusan.php"); } 
if ($e_jurusan!=''){ include ("page-jurusan.php"); }
//Menu Jabatan//
$ed_jabatan=$_GET['id_jabatan'];
if ($page=='jabatan'){ include ("v_jabatan.php"); } 
if ($ed_jabatan!=''){ include ("v_jabatan.php"); }
//Menu Pangkat//
$ed_pangkat=$_GET['id_pangkat'];
if ($page=='pangkat'){ include ("v_pangkat.php"); } 
if ($ed_pangkat!=''){ include ("v_pangkat.php"); }

//Menu Pelajaran//
$ed_pelajaran=$_GET['id_pelajaran'];
if ($page=='pelajaran'){ include ("v_pelajaran.php"); } 
if ($ed_pelajaran!=''){ include ("v_pelajaran.php"); }

//Menu Profil//
$ed_profil=$_GET['id_profil'];
if ($page=='profil'){ include ("v_profil.php"); } 
if ($ed_profil!=''){ include ("v_profil.php"); }

//Menu Agenda//
$ed_agenda=$_GET['id_agenda'];
if ($page=='agenda'){ include ("v_agenda.php"); } 
if ($ed_agenda!=''){ include ("v_agenda.php"); }

//Menu Artikel//
$ed_artikel=$_GET['id_artikel'];
if ($page=='artikel'){ include ("v_artikel.php"); } 
if ($ed_artikel!=''){ include ("v_artikel.php"); }

//Menu Berita//
$ed_berita=$_GET['id_berita'];
if ($page=='berita'){ include ("v_berita.php"); } 
if ($ed_berita!=''){ include ("v_berita.php"); }

//Menu Info Sekolah//
$ed_info_sekolah=$_GET['id_info_sekolah'];
if ($page=='info-sekolah'){ include ("v_info_sekolah.php"); } 
if ($ed_info_sekolah!=''){ include ("v_info_sekolah.php"); }

//Menu Info Alumni//
$ed_info_alumni=$_GET['id_info_alumni'];
if ($page=='info-alumni'){ include ("v_info_alumni.php"); } 
if ($ed_info_alumni!=''){ include ("v_info_alumni.php"); }

//Menu Prestasi//
$ed_prestasi=$_GET['id_prestasi'];
if ($page=='prestasi'){ include ("v_prestasi.php"); } 
if ($ed_prestasi!=''){ include ("v_prestasi.php"); }

//Menu Guru//
$ed_guru=$_GET['id_guru'];
if ($page=='guru'){ include ("v_guru.php"); } 
if ($ed_guru!=''){ include ("v_guru.php"); }	

//Menu Import Guru//
if ($page=='import_guru'){ include ("v_import_guru.php"); } 	

//Menu Siswa//
$ed_siswa=$_GET['id_siswa'];
if ($page=='siswa'){ include ("v_siswa.php"); } 
if ($ed_siswa!=''){ include ("v_siswa.php"); }	

//Menu Import Siswa//
if ($page=='import_siswa'){ include ("v_import_siswa.php"); } 	

//Menu Mahasiswa//
$e_mahasiswa=$_GET['id_mahasiswa'];
if ($page=='mahasiswa'){ include ("page-mahasiswa.php"); } 
if ($e_mahasiswa!=''){ include ("page-mahasiswa.php"); }	
?> 