		<div class="col-md-6">
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Form User</h3>
                </div
				<!-- form start -->
                <form action="simpen.php?pg=tambah_user" method="POST" role="form">
                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Nama Pengguna</label>
                      <input type="text" name="username" class="form-control" id="exampleInputUsername" placeholder="Masukkan Nama Pengguna">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Password</label>
                      <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Masukkan Password Pengguna">
                    </div>
					 <div class="form-group">
                    <label>Level Pengguna</label>
                    <select name="level" class="form-control select2" style="width: 100%;">
                      <option selected="selected">Pilih Level Pengguna</option>
                      <option value="0">Admin</option>
					  <option value="1">Pegawai</option>
					  <option value="2">Pemohon</option>
                    </select>
                  </div>
                  <div class="box-footer">
                    <input type="submit" name="tambah" class="btn btn-info btn-flat glyphicon glyphicon-floppy-save" value="Simpan">
                  </div>
                </form>
              </div>    