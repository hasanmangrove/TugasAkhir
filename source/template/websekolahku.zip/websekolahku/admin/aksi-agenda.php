<?php
include ('koneksi/koneksi.php');
$id_agenda=$_POST['id_agenda'];
$nama_agenda=$_POST['nama_agenda'];
$tanggal_mulai=($_POST['tanggal_mulai']);
$tanggal_akhir=($_POST['tanggal_akhir']);
$isi_agenda=($_POST['isi_agenda']);
$keterangan=($_POST['keterangan']);
$kategori=($_POST['kategori']);
if (isset($_POST['tambah'])){
$query="INSERT INTO tb_agenda (id_agenda,nama_agenda,tanggal_mulai,tanggal_akhir,isi_agenda,keterangan,id_kategori) 
values('','$nama_agenda','$tanggal_mulai','$tanggal_akhir','$isi_agenda','$keterangan','$kategori')"or die(mysql_error());
$tambah=mysql_query($query);			
	if($query){
			?><script language="JavaScript">
			alert('Agenda berhasil di tambahkan !');
			document.location='page.php?pg=agenda';
		</script><?php
		}	
}
else if ($_POST['update']){
$ubah = mysql_query("UPDATE tb_agenda SET  id_agenda='$id_agenda',nama_agenda='$nama_agenda',
tanggal_mulai='$tanggal_mulai',
tanggal_akhir='$tanggal_akhir',
isi_agenda='$isi_agenda',
keterangan='$keterangan',
id_kategori='$kategori'
 where id_agenda='$id_agenda'")or die(mysql_error());
if($ubah){		
?>
			<script language="JavaScript">
			alert('Agenda berhasil di ubah !');
			document.location='page.php?pg=agenda';
		</script>
<?php
		}
}
else if ($_GET['hapus']){
$id_agenda = $_GET['hapus'];
$del="DELETE FROM tb_agenda where id_agenda='$id_agenda'";
  $del= mysql_query($del);
if($del){
			?><script language="JavaScript">
			alert('Agenda berhasil di hapus !');
			document.location='page.php?pg=agenda';
		</script><?php
		}
}
header("location:page.php?pg=agenda");
?>