<?php
include ('koneksi/koneksi.php');
$nip=$_POST['nip'];
$nama_guru=($_POST['nama_guru']);
$tempat_lahir=($_POST['tempat_lahir']);
$tanggal_lahir=($_POST['tanggal_lahir']);
$jenis_kelamin=($_POST['jenis_kelamin']);
$nama_agama=($_POST['nama_agama']);
$alamat=($_POST['alamat']);
$nomor_hp=($_POST['nomor_hp']);
$email=($_POST['email']);
$jurusan=($_POST['pangkat']);
$nilai=($_POST['jabatan']);
$pelajaran=($_POST['pelajaran']);
$pangkat=($_POST['pangkat']);
$jabatan=($_POST['jabatan']);
$tugas=($_POST['tugas']);
$photo=($_POST['photo']);
$keterangan=($_POST['keterangan']);
if (isset($_POST['tambah'])){
if ($_FILES['photo']['size'] != 0){
$fileName= $_FILES['photo']['name'];
$movefile = move_uploaded_file($_FILES['photo']['tmp_name'], 'img/guru/'.$fileName); 
}
$query="INSERT INTO tb_guru (id_guru,nama_guru,nip,jenis_kelamin,agama,alamat,tugas,nomor_hp,email,pelajaran,tanggal_lahir,tempat_lahir,pangkat,
jabatan,photo,keterangan)
values('','$nama_guru','$nip','$jenis_kelamin','$nama_agama','$alamat',
'$tugas','$nomor_hp','$email','$pelajaran','$tanggal_lahir','$tempat_lahir',
'$pangkat','$jabatan','$fileName','$keterangan')"or die(mysql_error());
$tambah=mysql_query($query);			
	if($query){
			?><script language="JavaScript">
			alert('Data guru berhasil di simpan !');
			document.location='page.php?pg=guru';
		</script><?php
		}	
}
else if ($_POST['update']){
$id_guru=$_POST['id_guru'];
$ednip=$_POST['ednip'];
$ednama_guru=($_POST['ednama_guru']);
$edtempat_lahir=($_POST['edtempat_lahir']);
$edtanggal_lahir=($_POST['edtanggal_lahir']);
$edjenis_kelamin=($_POST['edjenis_kelamin']);
$ubah_agama=($_POST['ednama_agama']);
$edalamat=($_POST['edalamat']);
$ednomor_hp=($_POST['ednomor_hp']);
$edemail=($_POST['edemail']);
$ubah_pangkat=($_POST['ednama_pangkat']);
$ubah_jabatan=($_POST['ednama_jabatan']);
$ubah_pelajaran=($_POST['ednama_pelajaran']);
$edtugas=($_POST['edtugas']);
$edphoto=($_POST['edphoto']);
$edketerangan=($_POST['edketerangan']);
if ($_FILES['edphoto']['size'] != 0){
$filephoto= $_FILES['edphoto']['name'];
$ubahfile = move_uploaded_file($_FILES['edphoto']['tmp_name'], 'img/guru/'.$filephoto); 
}
$ubah = mysql_query("UPDATE tb_guru SET id_guru='$id_guru',
nama_guru='$ednama_guru',
nip='$ednip',
jenis_kelamin='$edjenis_kelamin',
agama='$ubah_agama',
alamat='$edalamat',
tugas='$edtugas',
nomor_hp='$ednomor_hp',
email='$edemail',
pelajaran='$ubah_pelajaran',
tanggal_lahir='$edtanggal_lahir',
tempat_lahir='$edtempat_lahir',
pangkat='$ubah_pangkat',
jabatan='$ubah_jabatan',
photo='$filephoto',
keterangan='$edketerangan' where id_guru='$id_guru'")or die(mysql_error());
if($ubah){		
?>
			<script language="JavaScript">
			alert('Data guru berhasil di ubah !');
			document.location='page.php?pg=guru';
		</script>
<?php
		}
}
else if ($_GET['hapus']){
$id_guru = $_GET['hapus'];
$del="DELETE FROM tb_guru where id_guru='$id_guru'";
  $del= mysql_query($del);
if($del){
			?><script language="JavaScript">
			alert('Data guru berhasil di hapus !');
			document.location='page.php?pg=guru';
		</script><?php
		}
}
header("location:page.php?pg=guru");
?>