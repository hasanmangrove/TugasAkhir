<?php
include ('koneksi/koneksi.php');
$id_berita=$_POST['id_berita'];
$judul_berita=$_POST['judul_berita'];
$isi_berita=($_POST['isi_berita']);
$pengirim=($_POST['pengirim']);
$jam_posting=($_POST['jam_posting']);
$tanggal_posting=($_POST['tanggal_posting']);
$kategori=($_POST['kategori']);
if (isset($_POST['tambah'])){
$query="INSERT INTO tb_berita (id_berita,judul_berita,isi_berita,pengirim,posttime,postdate,id_kategori) 
values('','$judul_berita','$isi_berita','$pengirim','$jam_posting','$tanggal_posting','$kategori')"or die(mysql_error());
$tambah=mysql_query($query);			
	if($query){
			?><script language="JavaScript">
			alert('Berita berhasil di tambahkan !');
			document.location='page.php?pg=berita';
		</script><?php
		}	
}
else if ($_POST['update']){
$ubah = mysql_query("UPDATE tb_berita SET  id_berita='$id_berita',judul_berita='$judul_berita',
isi_berita='$isi_berita',
pengirim='$pengirim',
posttime='$jam_posting',
postdate='$tanggal_posting',
id_kategori='$kategori'
 where id_berita='$id_berita'")or die(mysql_error());
if($ubah){		
?>
			<script language="JavaScript">
			alert('Berita berhasil di ubah !');
			document.location='page.php?pg=berita';
		</script>
<?php
		}
}
else if ($_GET['hapus']){
$id_berita = $_GET['hapus'];
$del="DELETE FROM tb_berita where id_berita='$id_berita'";
  $del= mysql_query($del);
if($del){
			?><script language="JavaScript">
			alert('Berita berhasil di hapus !');
			document.location='page.php?pg=berita';
		</script><?php
		}
}
header("location:page.php?pg=berita");
?>