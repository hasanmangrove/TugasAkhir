<?php
include ('koneksi/koneksi.php');
$id_profil=$_POST['id_profil'];
$nama_profil=$_POST['nama_profil'];
$isi_profil=($_POST['isi_profil']);
$pengirim=($_POST['pengirim']);
$jam_posting=($_POST['jam_posting']);
$tanggal_posting=($_POST['tanggal_posting']);
if (isset($_POST['tambah'])){
$query="INSERT INTO tb_profil (id_profil,judul_profil,isi_profil,author,posttime,postdate) 
values('','$nama_profil','$isi_profil','$pengirim','$jam_posting','$tanggal_posting')"or die(mysql_error());
$tambah=mysql_query($query);			
	if($query){
			?><script language="JavaScript">
			alert('Profil berhasil di tambahkan !');
			document.location='page.php?pg=profil';
		</script><?php
		}	
}
else if ($_POST['update']){
$ubah = mysql_query("UPDATE tb_profil SET  id_profil='$id_profil',
judul_profil='$nama_profil',
isi_profil='$isi_profil',
author='$pengirim',
posttime='$jam_posting',
postdate='$tanggal_posting'
 where id_profil='$id_profil'")or die(mysql_error());
if($ubah){		
?>
			<script language="JavaScript">
			alert('Profil berhasil di ubah !');
			document.location='page.php?pg=profil';
		</script>
<?php
		}
}
else if ($_GET['hapus']){
$id_profil = $_GET['hapus'];
$del="DELETE FROM tb_profil where id_profil='$id_profil'";
  $del= mysql_query($del);
if($del){
			?><script language="JavaScript">
			alert('Data Profil berhasil di hapus !');
			document.location='page.php?pg=profil';
		</script><?php
		}
}
header("location:page.php?pg=profil");
?>