<?php session_start(); 	$page=$_GET['pg']; ?>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SIMPONI | Dashboard</title>
	 <!-- Memanggil file pendukung website -->
	<?php include "pendukung.php" ?>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
	<!-- Memanggil file header -->
	<?php include "header.php" ?>
    <!-- Memanggil file menu sebelah kiri -->
	<?php include "menu-left.php" ?>
    <!-- Memanggil file content -->
	 <div class="content-wrapper">
        <section class="content-header">
          <h1>
            Sistem Informasi Manajemen Perizinan
            <small>Pemerintah Kabupaten Wakatobi</small>
          </h1>
          <ol class="breadcrumb">
		  <?php if ($page=='home'){?>	
            <li><a href="#"><i class="fa fa-dashboard"></i> Home </a></li> <li class="active">Dashboard</li>
          <?php } ?>
		  <?php if ($page=='pengguna'){?>	
            <li><a href="#"><i class="fa fa-dashboard"></i> Pengaturan </a></li> <li class="active">Pengguna</li>
          <?php } ?>
		  </ol>
		  <hr style="border-color:black;border-height:5px;">
        </section>
        <!-- Main content -->
        <section class="content">
    <?php 
	if ($page=='home'){ include ("halaman1.php"); }	
	if ($page=='pengguna'){ include ("user.php"); }  	
	?> 
		</section>
	</div>
	<!-- Memanggil file footer -->
    <?php include "footer.php" ?>   
      <!-- Control Sidebar -->
    <?php include "sidebar.php" ?> 
    <!-- Memanggil file pendukung lain jQuery 2.1.4 -->
    <?php include "pendukung-lain.php" ?>
	</div><!-- ./wrapper -->
  </body>
</html>
