<?php
header('location:login');
?>