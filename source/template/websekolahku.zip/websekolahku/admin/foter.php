<footer class="main-footer">
        <div class="pull-right hidden-xs">
          
        </div>
        <strong>Copyright &copy; 2016 <a href="http://sman1raha.sch.id"> SMA Negeri 1 Raha</a>. </strong> All rights reserved.
      </footer>