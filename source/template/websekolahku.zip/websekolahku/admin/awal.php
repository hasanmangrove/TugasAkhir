<?php
$page=$_GET['pg'];
// Bagian login
if ($page=='login'){
include ("login.php");
}
?>