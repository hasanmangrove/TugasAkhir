<?php
include ('koneksi/koneksi.php');
$nis=$_POST['nis'];
$nama_siswa=($_POST['nama_siswa']);
$tempat_lahir=($_POST['tempat_lahir']);
$tanggal_lahir=($_POST['tanggal_lahir']);
$jenis_kelamin=($_POST['jenis_kelamin']);
$nama_agama=($_POST['nama_agama']);
$alamat=($_POST['alamat']);
$nomor_hp=($_POST['nomor_hp']);
$email=($_POST['email']);
$jurusan=($_POST['jurusan']);
$nilai=($_POST['nilai']);
$keterangan=($_POST['keterangan']);
$nama_ayah=($_POST['nama_ayah']);
$nama_ibu=($_POST['nama_ibu']);
$photo=($_POST['photo']);
$status=($_POST['status']);
if (isset($_POST['tambah'])){
if ($_FILES['photo']['size'] != 0){
$fileName= $_FILES['photo']['name'];
$movefile = move_uploaded_file($_FILES['photo']['tmp_name'], 'img/siswa/'.$fileName); 
}
$query="INSERT INTO tb_siswa (id_siswa,nis,nama_siswa,tempat_lahir,tanggal_lahir,jenis_kelamin,
agama,alamat,nomor_hp,email,jurusan,nilai,keterangan,nama_ayah,nama_ibu,photo,status)
values('','$nis','$nama_siswa','$tempat_lahir','$tanggal_lahir','$jenis_kelamin',
'$nama_agama','$alamat','$nomor_hp','$email','$jurusan','$nilai',
'$keterangan','$nama_ayah','$nama_ibu','$fileName','$status')"or die(mysql_error());
$tambah=mysql_query($query);			
	if($query){
			?><script language="JavaScript">
			alert('Data siswa berhasil di simpan !');
			document.location='page.php?pg=siswa';
		</script><?php
		}	
}
else if ($_POST['update']){
$id_siswa=$_POST['id_siswa'];
$ednis=$_POST['ednis'];
$ednama_siswa=($_POST['ednama_siswa']);
$edtempat_lahir=($_POST['edtempat_lahir']);
$edtanggal_lahir=($_POST['edtanggal_lahir']);
$edjenis_kelamin=($_POST['edjenis_kelamin']);
$ubah_agama=($_POST['ednama_agama']);
$edalamat=($_POST['edalamat']);
$ednomor_hp=($_POST['ednomor_hp']);
$edemail=($_POST['edemail']);
$ubah_jurusan=($_POST['ednama_jurusan']);
$ednilai=($_POST['ednilai']);
$edketerangan=($_POST['edketerangan']);
$ednama_ayah=($_POST['ednama_ayah']);
$ednama_ibu=($_POST['ednama_ibu']);
$edphoto=($_POST['edphoto']);
$edstatus=($_POST['edstatus']);
if ($_FILES['edphoto']['size'] != 0){
$filephoto= $_FILES['edphoto']['name'];
$ubahfile = move_uploaded_file($_FILES['edphoto']['tmp_name'], 'img/siswa/'.$filephoto); 
}
$ubah = mysql_query("UPDATE tb_siswa SET id_siswa='$id_siswa',
nis='$ednis',
nama_siswa='$ednama_siswa',
tempat_lahir='$edtempat_lahir',
tanggal_lahir='$edtanggal_lahir',
jenis_kelamin='$edjenis_kelamin',
agama='$ubah_agama',
alamat='$edalamat',
nomor_hp='$ednomor_hp',
email='$edemail',
jurusan='$ubah_jurusan',
nilai='$ednilai',
keterangan='$edketerangan',
nama_ayah='$ednama_ayah',
nama_ibu='$ednama_ibu',
photo='$filephoto',
status='$edstatus' where id_siswa='$id_siswa'")or die(mysql_error());
if($ubah){		
?>
			<script language="JavaScript">
			alert('Data siswa berhasil di ubah !');
			document.location='page.php?pg=siswa';
		</script>
<?php
		}
}
else if ($_GET['hapus']){
$id_siswa = $_GET['hapus'];
$del="DELETE FROM tb_siswa where id_siswa='$id_siswa'";
  $del= mysql_query($del);
if($del){
			?><script language="JavaScript">
			alert('Data siswa berhasil di hapus !');
			document.location='page.php?pg=siswa';
		</script><?php
		}
}
header("location:page.php?pg=siswa");
?>