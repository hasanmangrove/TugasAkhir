<?php
$page=$_GET['pg'];
if ($page=='cek'){
session_start();
if (empty($_SESSION[namauser]) AND empty($_SESSION[passuser])){
 echo "<script language='JavaScript'>
			alert('Username dan password tidak boleh kosong atau harus benar !');
			document.location='simpen.php?pg=login';
		</script>";
 }
else{
 include "koneksi/koneksi.php";
 if ($_SESSION['lvl']=='0'){
  $sql=mysql_query("SELECT * FROM user WHERE Level='0'");
  $level=mysql_num_rows($sql);
  $r=mysql_fetch_array($sql);
  header('location:simpen.php?pg=home');
  }
  elseif ($_SESSION['lvl']=='1'){
    $sql=mysql_query("SELECT * FROM user WHERE Level='1'");
    $level=mysql_num_rows($sql);
    $r=mysql_fetch_array($sql);
 header('location:simpen.php?pg=home');
  }
  elseif ($_SESSION['lvl']=='2'){
    $sql=mysql_query("SELECT * FROM user WHERE Level='2'");
    $level=mysql_num_rows($sql);
    $r=mysql_fetch_array($sql);
 header('location:simpen.php?pg=home');
  }
 }
 }
?>