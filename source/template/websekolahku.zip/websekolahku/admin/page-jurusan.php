<?php if (isset($_SESSION['username'])){ ?> 
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Admin | Data Jurusan</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
	<?php include('header.php'); ?>
      <!-- Left side column. contains the logo and sidebar -->
	<?php include ('menu-left.php'); ?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <?php include ('breadcrumbs.php'); ?>
		<!-- Main content -->
<?php
include ('koneksi/koneksi.php');
if($_SESSION['leveluser']==0){
//*********** Menampilkan Data dari tabel user ***********//
$daftar=mysql_query("select * from tb_jurusan order by kode_jurusan Asc");
}
//else if($_SESSION['leveluser']==1 OR $_SESSION['leveluser']==2) {
//$pengguna=$_SESSION['namauser'];
//*********** Menampilkan Data dari tabel user ***********//
//$daftar=mysql_query("select * from user where Username='$pengguna'order by Level Asc");
 //}
 ?>
 <?php
 if ($_GET['id_jurusan']){
 $id = $_GET['id_jurusan'];
							$query=mysql_query("SELECT * FROM tb_jurusan where id_jurusan='$id'")or die(mysql_error());
							while($row=mysql_fetch_array($query)){
							$id=$row['id_jurusan'];
							?>	
		 <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                  <li class="active"><a href="#fa-icons" data-toggle="tab">Edit Data Jurusan</a></li>
                </ul>
                <div class="tab-content">
				<div class="box">
                <div class="box-header with-border">
                  <h3 class="box-title">Formulir Edit Data Jurusan</h3>
                </div
				<!-- form start -->
                <form action="aksi-jurusan.php" method="POST" role="form">
                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Kode Jurusan</label>
					  <input type="hidden" name="id" value="<?php echo $row['id_jurusan'] ?>" style="width: 30%;" class="form-control" id="exampleInputUsername">
                      <input type="text" name="kode_jurusan" value="<?php echo $row['kode_jurusan'] ?>" style="width: 30%;" class="form-control" id="exampleInputUsername">
                    </div>
					<div class="form-group">
                      <label for="exampleInputEmail1">Nama Jurusan</label>
					  <input type="text" name="nama_jurusan" value="<?php echo $row['nama_jurusan'] ?>" style="width: 30%;" class="form-control" id="exampleInputUsername">
                    </div>
					 <div class="form-group">
                    <label>Nama Sekolah</label>
                    <select name="nama_sekolah" class="form-control select2" style="width: 30%;">
					<option value="SMA Negeri 1 Raha">SMA Negeri 1 Raha</option>
					   <!--
						<option value="<?php echo $row['Level'] ?>">
						<?php $level=$row['Level'];
						If ($level=='0') { echo"Admin";}else If ($level=='1') { echo"Pegawai";}else If ($level=='2') { echo"Pengguna";}?>
						</option>
						<?php				
						if($_SESSION['leveluser']==0){
						echo "
							<option value='0'>Admin</option>
                            <option value='1'>Guru</option>
                            <option value='2'>Pegawai</option>
							";}
						?>-->
                    </select>
                  </div>
                  <div class="box-footer">
                    <input type="submit" name="update" class="btn btn-info btn-flat glyphicon glyphicon-floppy-save" value="Update">
                  </div>
                </form>
                  </div><!-- /#ion-icons -->
                </div><!-- /.tab-content -->
              </div><!-- /.nav-tabs-custom -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
<?php } } else { ?>
		 <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                  <li class="active"><a href="#fa-icons" data-toggle="tab">Tampilkan Daftar Jurusan</a></li>
                  <li><a href="#glyphicons" data-toggle="tab">Tambah Jurusan</a></li>
                </ul>
                <div class="tab-content">
                  <!-- Font Awesome Icons -->
                  <div class="tab-pane active" id="fa-icons">
               <div class="box">
                <div class="box-body scrolltable">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Kode Jurusan</th>
                        <th>Nama Jurusan</th>
                        <th>Fakultas</th>
                        <th>Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
<?php 
$counter = 1; 
while ($dt=mysql_fetch_array($daftar)){
$level_user=$dt['Level'];
echo "
			<tr>
				<td>$counter</td>
				<td class='center'>".$dt['kode_jurusan']."</td>
				<td class='center'>".$dt['nama_jurusan']."</td>
				<td class='center'>".$dt['nama_sekolah']."</td>
				<td class='center'><i class='glyphicon glyphicon-edit icon-white'></i><a href='page.php?id_jurusan=".$dt['id_jurusan']."'>Edit </a>";
				if($_SESSION['leveluser']==0){
				echo" <i class='glyphicon glyphicon-trash icon-white'>  </i>";?>
				<a onClick="return confirm('Apakah Anda yakin menghapus nama jurusan ini ?')"<?php echo"href='aksi-jurusan.php?hapus=".$dt['id_jurusan']."'>Hapus</a>";	} ?> </td>
			</tr>
<?php $counter ++; } ?>
                    </tbody>
                  </table>
                </div>
              </div>
              </div>
              <div class="tab-pane" id="glyphicons">
              <div class="box">
                <div class="box-header with-border">
                  <h3 class="box-title">Formulir Input Data Jurusan</h3>
                </div
				<!-- form start -->
                <form action="aksi-jurusan.php" method="POST" role="form">
                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Kode Jurusan</label>
                      <input type="text" name="kode_jurusan" style="width: 30%;" class="form-control" id="exampleInputUsername" placeholder="Masukkan Kode Jurusan">
                    </div>
					<div class="form-group">
                      <label for="exampleInputEmail1">Nama Jurusan</label>
                      <input type="text" name="nama_jurusan" style="width: 30%;" class="form-control" id="exampleInputUsername" placeholder="Masukkan Nama Jurusan">
                    </div>
					 <div class="form-group">
                    <label>Nama Sekolah</label>
                    <select name="nama_sekolah" class="form-control select2" style="width: 30%;">
                      <option selected="selected">Pilih Sekolah</option>
                      <option value="SMA Negeri 1 Raha">SMA Negeri 1 Raha</option>
                    </select>
                  </div>
                  <div class="box-footer">
                    <input type="submit" name="tambah" class="btn btn-info btn-flat glyphicon glyphicon-floppy-save" value="Simpan">
                  </div>
                </form>
                  </div><!-- /#ion-icons -->
                </div><!-- /.tab-content -->
              </div><!-- /.nav-tabs-custom -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
	<?php } ?>
      </div><!-- /.content-wrapper -->
    <?php include ('foter.php'); ?>
      <!-- Control Sidebar -->
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!-- DataTables -->
    <script src="plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="plugins/datatables/dataTables.bootstrap.min.js"></script>
    <!-- SlimScroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <!-- page script -->
    <script>
      $(function () {
        $("#example1").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>
  </body>
</html>
<?php } else  { 
echo "<script language='javascript'>history.back();</script>";}?>