<?php
include ('koneksi/koneksi.php');
$id_jabatan=$_POST['id_jabatan'];
$nama_jabatan=$_POST['nama_jabatan'];
if (isset($_POST['tambah'])){
$query="INSERT INTO tb_jabatan (id_jabatan,nama_jabatan) values('','$nama_jabatan')"or die(mysql_error());
$tambah=mysql_query($query);			
	if($query){
			?><script language="JavaScript">
			alert('Nama jabatan berhasil di tambahkan !');
			document.location='page.php?pg=jabatan';
		</script><?php
		}	
}
else if ($_POST['update']){
$ubah = mysql_query("UPDATE tb_jabatan SET nama_jabatan='$nama_jabatan' where id_jabatan='$id_jabatan'")or die(mysql_error());
if($ubah){		
?>
			<script language="JavaScript">
			alert('Nama jabatan berhasil di ubah !');
			document.location='page.php?pg=jabatan';
		</script>
<?php
		}
}
else if ($_GET['hapus']){
$id_jabatan = $_GET['hapus'];
$del="DELETE FROM tb_jabatan where id_jabatan='$id_jabatan'";
  $del= mysql_query($del);
if($del){
			?><script language="JavaScript">
			alert('Nama jabatan berhasil di hapus !');
			document.location='page.php?pg=jabatan';
		</script><?php
		}
}
header("location:page.php?pg=jabatan");
?>