<?php session_start(); 	$page=$_GET['pg']; ?>
<section class="content-header">
          <h1>
          </h1>
  <ol class="breadcrumb">
<?php if ($page=='home'){ ?> <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Dashboard</li><?php }
if ($page=='pengguna'){ ?> <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Pengguna</li><?php } ?>
<?php if ($page=='jurusan'){ ?> <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Jurusan</li><?php } ?>
<?php if ($page=='mahasiswa'){ ?> <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li><li class="active">Mahasiswa</li><?php } ?> 
 </ol>
</section><br>